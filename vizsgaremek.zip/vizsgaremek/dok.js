//event div movement
window.onload = function() {
    const div = document.getElementById('dok-event')
    const dokContent = document.getElementById('dok-container')

    const contentTopPosition = dokContent.getBoundingClientRect().top + window.scrollY

    div.style.top = contentTopPosition + 'px'

    window.addEventListener('scroll', function() {
        const scrollPosition = window.scrollY

        let smoothTop = contentTopPosition - scrollPosition

        smoothTop = Math.max(smoothTop, 0)

        div.style.top = smoothTop + 'px'
    })
}

document.getElementById("TopButton").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    })
})

//event date 
document.addEventListener('DOMContentLoaded', function() {
    const eventDate = document.getElementById('event-date')
    const today = new Date().toISOString().split('T')[0]
    const dateInput = document.getElementById('dok-event-date')
    dateInput.setAttribute('min', today)

    document.querySelectorAll('input[name="add-event"]').forEach((radio) => {
        radio.addEventListener('change', function() {
            eventDate.hidden = document.querySelector('input[name="add-event"]:checked').value != "igen"
        })
    })
})

//vote input 
function Vote(){
    const popup = document.getElementById('voteWindow')
    popup.style.display = 'flex'
}
document.getElementById('closeVote').addEventListener('click', function() {
    const popup = document.getElementById('voteWindow')
    popup.style.display = 'none'
})
document.getElementById('addVote').addEventListener('click', function() {
    var newInput = document.createElement('input')
    newInput.type = 'text'
    newInput.name = 'input' + (document.querySelectorAll('#votes-container input').length)
    document.getElementById('votes-container').appendChild(newInput)
    document.getElementById('votes-container').appendChild(document.createElement('br'))
})