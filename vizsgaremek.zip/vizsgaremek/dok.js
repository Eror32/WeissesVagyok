const div = document.getElementById('dok-event')
const initialPosition = div.getBoundingClientRect().top + window.scrollY

const dokContent = document.getElementById('dok-container')
const contentTopPosition = dokContent.getBoundingClientRect().top + window.scrollY

window.addEventListener('scroll', function() {
    const scrollPosition = window.scrollY
    let smoothTop = initialPosition - scrollPosition * 1
    smoothTop = Math.max(smoothTop, 0)
    div.style.top = smoothTop + 'px'

    if (smoothTop > contentTopPosition) div.style.top = contentTopPosition + 'px'
})

document.getElementById("TopButton").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    })
})

document.addEventListener('DOMContentLoaded', function() {
    const eventDate = document.getElementById('event-date');
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('dok-event-date');
    dateInput.setAttribute('min', today);

    document.querySelectorAll('input[name="add-event"]').forEach((radio) => {
        radio.addEventListener('change', function() {
            eventDate.hidden = document.querySelector('input[name="add-event"]:checked').value != "igen";
        });
    });
});