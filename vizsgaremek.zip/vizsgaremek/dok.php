<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Weiss Diákönkormányzat</title>
    <link rel="stylesheet" href="dok.css">
    <script src="dok.js" defer></script>
</head>
<body style="margin:0px; min-width: 1210px;">



    <div id="dok-search">
        <input placeholder="Keresés...">
        <span><img src="images/magnifying-glass.png"></span>
    </div>

    <div id="dok-container">
        <div class="dok-content">
            <?php
                $user = mysqli_fetch_array(mysqli_query($adb, "SELECT * FROM user WHERE uid='$_SESSION[uid]'"));  

                if ($user['ustatusz']=='D'){    
                    print('
                        <form action="dok_post_ir.php" method=post target="kisablak" style="background: transparent; box-shadow: none;">
                        
                            <div id="voteWindow" style="display: none;">
                                <div>
                                    <h2>Opciók megadása:</h2>
                                    <p id="votes-container">
                                        <input type="text" name="input0"><br>
                                    </p>
                                    <br><br>
                                    <p style ="font-size: 11px;"><u>Megjegyzés:</u><br>
                                    <i>A „Kilépés” gomb automatikusan menti a megadott adatokat. Ha nem szeretne szavazást létrehozni, vagy nincs szüksége a létrehozott mezőre, hagyja üresen!</i></p>
                                    <label id="closeVote">Kilépés</label>
                                    <label id="addVote">Hozzáadás</label>
                                </div>
                            </div>

                            <textarea name="dtext" onclick="this.style.height=`215px`"></textarea>
                            
                            <label for="dok-post-vote" onclick="Vote(this)">Szavazás létrehozása</label><input type="button" name="dok-post-vote" style="display: none">
                            <label for="dok-post-file">Fájl csatolása</label><input type="file" name="dok-post-file" style="display: none">
                            
                            <dl>
                                <dt>Szeretné eseményként kezelni? </dt>
                                <dd style="margin-left: 132px"> Igen <input type="radio" id="dok-event-add" name="add-event" value="igen"> </dd>
                                <dd style="margin-left: 130px" id="event-date" hidden> Dátum: <input type="date" id="dok-event-date" name="event-date"></dd>
                                <dd style="margin-left: 130px"> Nem <input type="radio" id="dok-event-add" name="add-event" value="nem" checked> </dd>
                            </dl>

                            <label for="dok-post-send">Közzététel</label><input type="submit" id="dok-post-send" style="display: none">
                            <hr>
                        </form>
                        
                    ');
                }

                $query = mysqli_query($adb, "SELECT * FROM dok WHERE dstatus = 'A' ORDER BY dpostid DESC");
                
                while ($dok = mysqli_fetch_assoc($query)) {

                    $puser = mysqli_fetch_array(mysqli_query($adb, "SELECT * FROM user WHERE uid='{$dok['duid']}' AND ustatusz!='I' ")); 
                    
                    $punick = $puser['unick'] ?? "Törölt felhasználó";
                    if ($puser['uprofkepnev']=="") $pupic ="images/alapkep.jfif";
                    else $pupic = "profilkepek/".$puser['uprofkepnev'];
                    
                    //nl2br = formázás (sortörés)
                    //htmlspecialchars = HTML tag elleni védelem
                    print(
                        '<div>
                            <a href="#">
                            <img src="'.$pupic.'"><b>'.$punick.'</b></a> <i style="font-size: 11px; color: grey;">'.$dok['dtime'].'</i>
                            
                            <br><br>
                            '.nl2br(htmlspecialchars($dok['dtext'])).'<br><br><p style="display: grid; width: 40%;">'
                        ); 
                    
                    if ($dok['dvote']!=""){
                        $votes= explode(';', $dok['dvote']);
                        
                        for($i=0; $i < Count($votes); $i++){
                            $identifier= $dok['dpostid'] . $i;
                            /*if (vchoice==$voteSplit[0]){
                            print('<label for="'.$identifier.'" style="line-height: 16px; background-color: rgba(0, 0, 0, 0.05); border-radius: 16px; padding: 6px;"><input type="radio" name="'.$dok['dpostid'].'" id="'.$identifier.'" checked>'.$votes[$i].' <i style="float:right; font-size: 12px;"> 0 szavazó</i></label>');
                            }
                            else*/

                            print('<label for="'.$identifier.'" style="line-height: 16px; background-color: rgba(0, 0, 0, 0.05); border-radius: 16px; padding: 6px;"><input type="radio" name="'.$dok['dpostid'].'" id="'.$identifier.'" >'.$votes[$i].' <i style="float:right; font-size: 12px;"> 0 szavazó</i></label>');
                        }
                    }
                    print('
                        </p></div>
                        ');
                }
                ?>
                
            
        </div>
    </div>
    <div id="dok-event">
        
        <div>
            B
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br ><br><br><br><br><br><br><br><br><br><br><br><br>
            
            B
        </div>
        <button id="TopButton"><img src="images/arrow-up.png" style="repeat: no-repeat; width: 100%;"></button>
    </div>





    
</body>
</html>