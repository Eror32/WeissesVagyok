<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Weiss Diákönkormányzat</title>
    <link rel="stylesheet" href="dok.css">
    <script src="dok.js" defer></script>
</head>
<body style="margin:0px; min-width: 1210px;">

    <div id="dok-search">
        <input placeholder="Keresés...">
        <span><img src="images/magnifying-glass.png"></span>
    </div>

    <div id="dok-container">
        <div class="dok-content">
            <?php
                $user = mysqli_fetch_array(mysqli_query($adb, "SELECT * FROM user WHERE uid='$_SESSION[uid]'"));  

                if ($user['ustatusz']=='D'){    
                    print('
                        <form action="dok_post_ir.php" method=post target="kisablak" style="background: transparent; box-shadow: none;">
                            <textarea name="dtext" onclick="this.style.height=`215px`"></textarea>
                            
                            
                            <label for="dok-post-vote">Szavazás létrehozása</label><input type="button" name="dok-post-vote" style="display: none">
                            <label for="dok-post-file">Fájl csatolása</label><input type="file" name="dok-post-file" style="display: none">
                            
                            <dl>
                                <dt>Szeretné eseményként kezelni? </dt>
                                <dd style="margin-left: 132px"> Igen <input type="radio" id="dok-event-add" name="add-event" value="igen"> </dd>
                                <dd style="margin-left: 130px" id="event-date" hidden> Dátum: <input type="date" id="dok-event-date" name="event-date"></dd>
                                <dd style="margin-left: 130px"> Nem <input type="radio" id="dok-event-add" name="add-event" value="nem" checked> </dd>
                            </dl>

                            <label for="dok-post-send">Közzététel</label><input type="submit" id="dok-post-send" style="display: none">
                            <hr>
                        </form>
                        
                    ');
                }

                $query = mysqli_query($adb, "SELECT * FROM dok WHERE dstatus = 'A' ");
                
                while ($dok = mysqli_fetch_assoc($query)) {

                    $puser = mysqli_fetch_array(mysqli_query($adb, "SELECT * FROM user WHERE uid='{$dok['duid']}'")); 
                    
                    $pupic = $puser['uprofkepnev'];
                    $punick = $puser['unick'] ?? 'Unknown User';
                    
                    //nl2br = formázás (sortörés)
                    //htmlspecialchars = HTML tag elleni védelem
                    print(
                        '<div>
                            <a href="#">
                            <img src="profilkepek/'.$pupic.'" alt="prof pic" style="width: 25px;"> '. $punick.'
                            </a>
                            <br><br>
                            '.nl2br(htmlspecialchars($dok['dtext'])).'
                            <br><br>
                        </div>
                    '); 
                }
           ?>
        </div>
    </div>
    <div id="dok-event">
        
        <div>
            B
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br ><br><br><br><br><br><br><br><br><br><br><br><br>
            
            B
        </div>
        <button id="TopButton"><img src="images/arrow-up.png" style="repeat: no-repeat; width: 100%;"></button>
    </div>





    
</body>
</html>