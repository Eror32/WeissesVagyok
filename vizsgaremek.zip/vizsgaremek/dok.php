<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Weiss Diákönkormányzat</title>
    <link rel="stylesheet" href="dok.css">
</head>
<body style="margin:0px; min-width: 1210px;">

    <div id="dok-search">
        <input placeholder="Keresés...">
        <span><img src="images/magnifying-glass.png"></span>
    </div>

    <div id="dok-content">
        <div>
            <?php
                $user = mysqli_fetch_array(mysqli_query($adb, "SELECT * FROM user WHERE uid='$_SESSION[uid]'"));  

                if ($user['ustatusz']=='D'){    
                    print('
                        <form action="dok_post_ir.php" method=post target="kisablak" style="background: transparent; box-shadow: none;">
                            <textarea name="dtext" onclick="this.style.height=`215px`"></textarea>
                            
                            
                            <label for="dok-post-vote">Szavazás létrehozása</label><input type="button" name="dok-post-vote" style="display: none">
                            <label for="dok-post-file">Fájl csatolása</label><input type="file" name="dok-post-file" style="display: none">
                            
                            <dl>
                                <dt>Eseményekhez adás: </dt>
                                <dd style="margin-left: 132px"> Igen <input type="radio" id="dok-event-add" name="add-event" value="igen"> </dd>
                                <dd style="margin-left: 130px"> Nem <input type="radio" id="dok-event-add" name="add-event" value="nem" checked> </dd>
                            </dl>

                            <label for="dok-post-send">Közzététel</label><input type="submit" id="dok-post-send" style="display: none">
                            <hr>
                        </form>
                    ');
                }








                
                //Kiírás:
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $recordsPerPage = 10;
                $offset = ($page - 1) * $recordsPerPage;
                $query = mysqli_query($adb, "SELECT * FROM dok WHERE dstatus = 'A' LIMIT $recordsPerPage OFFSET $offset");
                
                
                while ($dok = mysqli_fetch_assoc($query)) {
                    print(
                        '<p>'
                            .$dok['dtext'].'
                        </p>'
                    ); 
                }
            ?>

            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            A
        </div>
    </div>
    <div id="dok-event">
        
        <div>
            B
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br ><br><br><br><br><br><br><br><br><br><br><br><br>
            
            B
        </div>
        <button id="TopButton"><img src="images/arrow-up.png" style="repeat: no-repeat; width: 100%;"></button>
    </div>





    <script>        
        let div = document.getElementById('dok-event')
        let initialPosition = div.getBoundingClientRect().top + window.scrollY

        let dokContent = document.getElementById('dok-content')
        let contentTopPosition = dokContent.getBoundingClientRect().top + window.scrollY

        window.addEventListener('scroll', function() {
            let scrollPosition = window.scrollY
            let smoothTop = initialPosition - scrollPosition * 1
            smoothTop = Math.max(smoothTop, 0)
            div.style.top = smoothTop + 'px'

            if (smoothTop > contentTopPosition) div.style.top = contentTopPosition + 'px'
        })
        
        document.getElementById("TopButton").addEventListener("click", function() {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            })
        })
    </script>
</body>
</html>