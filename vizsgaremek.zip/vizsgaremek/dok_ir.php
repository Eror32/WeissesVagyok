<?php

    mysqli_query( $adb , "
		INSERT INTO dok (           did  ,     dpostid  ,         dpost  ,     dtime ,         dstatus) 
		VALUES          ('$_SESSION[uid]', '$strid' , '$_POST[unick]', '$md5pw', '$_POST[unev]')
    " ) ;

?>