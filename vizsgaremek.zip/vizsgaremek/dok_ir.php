<?php

    mysqli_query( $adb , "
		INSERT INTO dok (           did  ,     dpostid  ,         dpost  ,     dtime , dstatus) 
		VALUES          ('$_SESSION[uid]',     '$strid' , '$_POST[unick]',      NOW(),       A)
    " ) ;

?>