<?php
  session_start();
  include("kapcsolat.php") ;
  
  $addEvent= $_POST['add-event'];
  if ( $addEvent == 'igen') $event = 'Y';
  elseif ( $addEvent == 'nem') $event = 'N';


  mysqli_query( $adb , "
    INSERT INTO dok (          duid   ,	dpostid ,	dtextid ,	        dtext   ,  devent  ,	dtime ,	dstatus ) 
    VALUES          ('$_SESSION[uid]' ,    NULL ,       0 , '$_POST[dtext]' , '$event' ,  NOW() ,     'A' )
  " ) ;

?>