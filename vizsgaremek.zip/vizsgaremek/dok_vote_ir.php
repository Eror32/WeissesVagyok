<?php
    session_start();
    include("kapcsolat.php") ;
  
    $dpostid = intval($_POST['dpostid']); 
    $vuid = $_SESSION['uid'];
    $vchoice = $_POST[$dpostid];

    mysqli_query( $adb , "
      INSERT INTO votelog ( vdpostid, vuid, vchoice ) 
      VALUES          ( $dpostid, $vuid, '$vchoice' )
    " );
    print("<script>window.parent.location.reload();</script>");
?>